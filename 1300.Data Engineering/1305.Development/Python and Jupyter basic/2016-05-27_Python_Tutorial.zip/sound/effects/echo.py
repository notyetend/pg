def echofilter(s = ''):
    print('echo filter is called with param - %s' %(s))
def echofilter(s = ''):
    print('wave read is called with param - %s' %(s))